
public class sss {
  static double Sssdeduc (double wage){
    
    if (wage < 3250){
        return 135.00;
    }
    else if (wage >= 3250 && wage <= 3750){ return 157.50;
    }
    else if (wage >= 3750 && wage <= 4250){ return 180.00;
    }
    else if (wage >= 4250 && wage <= 4750){ return 202.50;
    }
    else if (wage >= 4750 && wage <= 5250){ return 225.00;
    }
    else if (wage >= 5250 && wage <= 5750){ return 247.50;
    }
    else if (wage >= 5750 && wage <= 6250){ return 270.00;
    }
    else if (wage >= 6250 && wage <= 6750){ return 292.50;
    }
    else if (wage >= 6750 && wage <= 7250){ return 315.00;
    }
    else if (wage >= 7250 && wage <= 7750){ return 337.50;
    }
    else if (wage >= 7750 && wage <= 8250){ return 360.00;
    }
    else if (wage >= 8250 && wage <= 8750){ return 382.50;
    }
    else if (wage >= 8750 && wage <= 9250){ return 405.00;
    }
    else if (wage >= 9250 && wage <= 9750){ return 427.50;
    }
    else if (wage >= 9750 && wage <= 10250){ return 450.00;
    }
    else if (wage >= 10250 && wage <= 10750){ return 472.50;
    }
    else if(wage >= 10750 && wage <= 11250){ return 495.00;
    }
    else if(wage >= 11250 && wage <= 11750){ return 517.50;
    }
    else if(wage >= 11750 && wage <= 12250){ return 540.00;
    }
    else if(wage >= 12250 && wage <= 12750){ return 562.50;
    }
    else if(wage >= 12750 && wage <= 13250){ return 585.00;
    }
    else if(wage >= 13250 && wage <= 13750){ return 607.50;
    }
    else if(wage >= 13750 && wage <= 14250){ return 630.00;
    }
    else if(wage >= 14250 && wage <= 14750){ return 652.50;
    }
    else if(wage >= 14750 && wage <= 15250){ return 675.00;
    }
    else if(wage >= 15250 && wage <= 15750){ return 697.50;
    }
    else if(wage >= 15750 && wage <= 16250){ return 720.00;
    }
    else if(wage >= 16250 && wage <= 16750){ return 742.50;
    }
    else if(wage >= 16750 && wage <= 17250){ return 765.00;
    }
    else if(wage >= 17250 && wage <= 17750){ return 787.50;
    }
    else if(wage >= 17750 && wage <= 18250){ return 810.00;
    }
    else if(wage >= 18250 && wage <= 18750){ return 832.50;
    }
    else if(wage >= 18750 && wage <= 19250){ return 855.00;
    }
    else if(wage >= 19250 && wage <= 19750){ return 877.50;
    }
    else if(wage >= 19750 && wage <= 20250){ return 900.00;
    }
    else if(wage >= 20250 && wage <= 20750){ return 922.50;
    }
    else if(wage >= 20750 && wage <= 21250){ return 945.00;
    }
    else if(wage >= 21250 && wage <= 21750){ return 967.50;
    }
    else if(wage >= 21750 && wage <= 22250){ return 990.00;
    }
    else if(wage >= 22250 && wage <= 22750){ return 1012.50;
    }
    else if(wage >= 22750 && wage <= 23250){ return 1035.00;
    }
    else if(wage >= 23250 && wage <= 23750){ return 1057.50;
    }
    else if(wage >= 23750 && wage <= 24250){ return 1080.00;
    }
    else if(wage >= 24250 && wage <= 24750){ return 1102.50;
    }
    else{
      return 11250.00;
    }

  }  
}